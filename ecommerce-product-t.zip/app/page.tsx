"use client"

import ProductPage from "../product-page"

export default function Page() {
  return <ProductPage />
}
