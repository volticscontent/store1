"use client"

import { useState, useEffect, useRef } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Label } from "@/components/ui/label"
import { Progress } from "@/components/ui/progress"
import { Trophy, DollarSign, Star } from "lucide-react"
import Image from "next/image"
import PriceAnchoring from "@/components/price-anchoring"

interface Question {
  id: number
  question: string
  options: string[]
  correct: number
  explanation: string
}

const questions: Question[] = [
  {
    id: 1,
    question: "In what year was the Oklahoma City Thunder founded?",
    options: ["2008", "1996", "2012", "1985"],
    correct: 0,
    explanation:
      "The Oklahoma City Thunder was founded in 2008 when the Seattle SuperSonics relocated to Oklahoma City.",
  },
  {
    id: 2,
    question: "What is Shai Gilgeous-Alexander's jersey number?",
    options: ["2", "5", "11", "0"],
    correct: 0,
    explanation: "Shai Gilgeous-Alexander wears jersey number 2 for the Oklahoma City Thunder.",
  },
  {
    id: 3,
    question: "In which city does the Thunder play home games?",
    options: ["Oklahoma City", "Dallas", "New York", "Miami"],
    correct: 0,
    explanation: "The Oklahoma City Thunder plays their home games at Paycom Center in Oklahoma City, Oklahoma.",
  },
  {
    id: 4,
    question: "What colors are on the official Oklahoma City Thunder jersey?",
    options: ["Blue and orange", "Red and white", "Green and yellow", "Black and gold"],
    correct: 0,
    explanation:
      "The Oklahoma City Thunder's official colors are blue and orange, representing the team's identity and energy.",
  },
]

// Enhanced notification component
const SuccessNotification = ({ show, onClose }: { show: boolean; onClose: () => void }) => {
  const [isVisible, setIsVisible] = useState(false)

  useEffect(() => {
    if (show) {
      setIsVisible(true)
      const timer = setTimeout(() => {
        setIsVisible(false)
        setTimeout(() => {
          onClose()
        }, 500) // Wait for exit animation
      }, 3000)

      return () => clearTimeout(timer)
    }
  }, [show, onClose])

  if (!show) return null

  return (
    <div
      className={`fixed top-4 right-4 z-50 transition-all duration-500 transform ${
        isVisible ? "translate-x-0 opacity-100 scale-100" : "translate-x-full opacity-0 scale-95"
      }`}
    >
      <div className="bg-gradient-to-r from-green-500 to-green-600 text-white px-6 py-4 rounded-lg shadow-2xl flex items-center space-x-3 border border-green-400">
        <div className="w-10 h-10 bg-white rounded-full flex items-center justify-center animate-pulse">
          <DollarSign className="h-6 w-6 text-green-500" />
        </div>
        <div>
          <p className="font-bold text-lg">Congratulations! 🎉</p>
          <p className="text-sm opacity-90">You earned $25 discount!</p>
        </div>
        <div className="w-2 h-2 bg-green-300 rounded-full animate-ping"></div>
      </div>
    </div>
  )
}

export default function PSGQuiz() {
  const [gameStarted, setGameStarted] = useState(false)
  const [currentQuestion, setCurrentQuestion] = useState(0)
  const [selectedAnswer, setSelectedAnswer] = useState("")
  const [correctAnswers, setCorrectAnswers] = useState(0)
  const [showResult, setShowResult] = useState(false)
  const [quizCompleted, setQuizCompleted] = useState(false)
  const [showNotification, setShowNotification] = useState(false)
  const [audioInitialized, setAudioInitialized] = useState(false)

  const audioRef = useRef<HTMLAudioElement | null>(null)

  // Initialize audio system
  useEffect(() => {
    const initializeAudio = () => {
      try {
        // Create audio element
        const audio = new Audio(
          "https://cdn.shopify.com/s/files/1/0946/2290/8699/files/notifica_o-venda.mp3?v=1749150271",
        )
        audio.preload = "auto"
        audio.volume = 0.8
        audioRef.current = audio

        // Try to initialize audio context for mobile
        const AudioContext = window.AudioContext || window.webkitAudioContext
        if (AudioContext) {
          const audioContext = new AudioContext()
          if (audioContext.state === "suspended") {
            audioContext.resume()
          }
        }

        setAudioInitialized(true)
        console.log("Audio system initialized successfully")
      } catch (error) {
        console.log("Error initializing audio:", error)
      }
    }

    // Initialize on first user interaction
    const handleFirstInteraction = () => {
      initializeAudio()
      document.removeEventListener("touchstart", handleFirstInteraction)
      document.removeEventListener("click", handleFirstInteraction)
      document.removeEventListener("keydown", handleFirstInteraction)
    }

    document.addEventListener("touchstart", handleFirstInteraction, { passive: true })
    document.addEventListener("click", handleFirstInteraction)
    document.addEventListener("keydown", handleFirstInteraction)

    return () => {
      document.removeEventListener("touchstart", handleFirstInteraction)
      document.removeEventListener("click", handleFirstInteraction)
      document.removeEventListener("keydown", handleFirstInteraction)
    }
  }, [])

  // Enhanced function to play notification sound
  const playNotificationSound = async () => {
    if (!audioRef.current) {
      console.log("Audio not initialized")
      return
    }

    try {
      // Reset audio to beginning
      audioRef.current.currentTime = 0

      // Multiple attempts for better compatibility
      const playAudio = async () => {
        try {
          await audioRef.current!.play()
          console.log("Notification sound played successfully!")
        } catch (error) {
          console.log("First attempt failed:", error)

          // Second attempt with new audio instance
          setTimeout(async () => {
            try {
              const newAudio = new Audio(
                "https://cdn.shopify.com/s/files/1/0946/2290/8699/files/notifica_o-venda.mp3?v=1749150271",
              )
              newAudio.volume = 0.8
              await newAudio.play()
              console.log("Second attempt successful!")
            } catch (secondError) {
              console.log("Second attempt failed:", secondError)

              // Third attempt with user interaction simulation
              setTimeout(() => {
                try {
                  const thirdAudio = new Audio(
                    "https://cdn.shopify.com/s/files/1/0946/2290/8699/files/notifica_o-venda.mp3?v=1749150271",
                  )
                  thirdAudio.volume = 0.8
                  thirdAudio.play()
                  console.log("Third attempt successful!")
                } catch (thirdError) {
                  console.log("All attempts failed:", thirdError)
                }
              }, 200)
            }
          }, 100)
        }
      }

      await playAudio()
    } catch (error) {
      console.log("General error playing notification sound:", error)
    }
  }

  const handleAnswer = () => {
    const isCorrect = Number.parseInt(selectedAnswer) === questions[currentQuestion].correct

    if (isCorrect) {
      setCorrectAnswers((prev) => prev + 1)
      setShowNotification(true)

      // Play sound immediately when answer is correct
      playNotificationSound()
    }

    setShowResult(true)
  }

  const nextQuestion = () => {
    if (currentQuestion < questions.length - 1) {
      setCurrentQuestion((prev) => prev + 1)
      setSelectedAnswer("")
      setShowResult(false)
    } else {
      setQuizCompleted(true)
    }
  }

  const discount = correctAnswers * 25
  const originalPrice = 150.0
  const finalPrice = Math.max(originalPrice - discount, 49.99)

  // Initial screen with the president
  if (!gameStarted) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-900 via-blue-800 to-orange-600 flex items-center justify-center p-4">
        {/* Hidden audio element for preloading */}
        <audio
          id="notification-sound"
          src="https://cdn.shopify.com/s/files/1/0946/2290/8699/files/notifica_o-venda.mp3?v=1749150271"
          preload="auto"
          style={{ display: "none" }}
        />

        <Card className="w-full max-w-3xl mx-2">
          <CardHeader className="text-center">
            <CardTitle className="text-4xl font-bold text-blue-900 mb-6">Message from Thunder Management</CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            {/* President photo */}
            <div className="flex justify-center mb-6">
              <div className="w-32 h-32 md:w-48 md:h-48 rounded-full overflow-hidden border-4 border-blue-300">
                <Image
                  src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Captura%20de%20Tela%202025-06-23%20a%CC%80s%2006.11.07-fAxXQPHIkOSCiDZDIhgWT8jJl6yeEQ.png"
                  alt="Thunder Management Executive"
                  width={192}
                  height={192}
                  className="w-full h-full object-cover"
                />
              </div>
            </div>

            <div className="bg-blue-50 p-6 rounded-lg border-2 border-blue-200">
              <blockquote className="text-sm md:text-lg text-gray-800 italic text-center leading-relaxed">
                "Loyal Thunder fans! ⚡🏀
                <br />
                <br />I am incredibly proud of what our team has accomplished this season.
                <br />
                <br />
                To celebrate this incredible journey, I'm offering you a <strong>once-in-a-lifetime opportunity</strong>
                : an official Thunder jersey signed by Shai Gilgeous-Alexander, personalized with his name and number,
                for just <strong>$49.99 instead of $150</strong>.
                <br />
                <br />
                Answer our 4 questions about the team correctly and unlock access to this exclusive offer!
                <br />
                <br />
                Together, let's make the Thunder roar.
                <br />
                <br />
                <strong>Go Thunder! 💙⚡🔥</strong>"
              </blockquote>
            </div>

            <div className="bg-yellow-50 p-4 rounded-lg border border-yellow-200">
              <div className="flex items-center justify-center space-x-2 text-yellow-800">
                <Star className="h-5 w-5" />
                <span className="font-semibold">Maximum discount: $100 • Final price: $49.99</span>
                <Star className="h-5 w-5" />
              </div>
            </div>

            <Button
              onClick={() => setGameStarted(true)}
              className="w-full bg-blue-600 hover:bg-blue-700 text-white text-xl py-6"
              size="lg"
            >
              <Trophy className="mr-2 h-6 w-6" />
              Start the Quiz
            </Button>
          </CardContent>
        </Card>
      </div>
    )
  }

  if (quizCompleted) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-900 via-blue-800 to-orange-600 flex items-center justify-center p-4">
        <Card className="w-full max-w-2xl mx-2">
          <CardHeader className="text-center">
            <div className="flex justify-center mb-4">
              <Trophy className="h-16 w-16 text-yellow-500" />
            </div>
            <CardTitle className="text-3xl font-bold text-blue-900">Congratulations, True Thunder Fan! 🎉</CardTitle>
            <CardDescription className="text-lg">
              You got {correctAnswers} correct answers out of {questions.length}
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <PriceAnchoring correctAnswers={correctAnswers} />

            <div className="flex flex-col gap-4">
              <Button
                className="bg-blue-600 hover:bg-blue-700 text-white w-full"
                size="lg"
                onClick={() => window.open("https://nbathunderr.shop/", "_blank")}
              >
                <DollarSign className="mr-2 h-5 w-5" />
                Buy Now
              </Button>
              <Button
                variant="outline"
                size="lg"
                className="w-full bg-transparent"
                onClick={() => window.location.reload()}
              >
                Start Over
              </Button>
            </div>

            <div className="text-center text-sm text-gray-600">
              <p>* Offer valid only for true Thunder fans</p>
              <p>** Special price: $49.99 (maximum discount applied)</p>
            </div>
          </CardContent>
        </Card>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-900 via-blue-800 to-orange-600 flex items-center justify-center p-4">
      <SuccessNotification show={showNotification} onClose={() => setShowNotification(false)} />

      <Card className="w-full max-w-2xl mx-2">
        <CardHeader>
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center space-x-2">
              <div className="w-8 h-8 rounded overflow-hidden">
                <Image
                  src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/alexander.jpg-yJWzzHVbBOK22oRDWw59IGExKSePHQ.jpeg"
                  alt="Thunder Jersey"
                  width={32}
                  height={32}
                  className="w-full h-full object-cover"
                />
              </div>
              <div>
                <CardTitle className="text-xl">Thunder Fan Quiz</CardTitle>
                <CardDescription>
                  Question {currentQuestion + 1} of {questions.length}
                </CardDescription>
              </div>
            </div>
            <div className="text-right">
              <p className="text-sm text-gray-600">Current discount</p>
              <p className="text-2xl font-bold text-green-600">${correctAnswers * 25}</p>
            </div>
          </div>
          <Progress value={(currentQuestion / questions.length) * 100} className="w-full" />
        </CardHeader>

        <CardContent className="space-y-6">
          {!showResult ? (
            <>
              <div className="bg-blue-50 p-6 rounded-lg">
                <h3 className="text-xl font-semibold mb-4 text-blue-900">{questions[currentQuestion].question}</h3>

                <RadioGroup value={selectedAnswer} onValueChange={setSelectedAnswer} className="space-y-3">
                  {questions[currentQuestion].options.map((option, index) => (
                    <div
                      key={index}
                      className="flex items-center space-x-2 p-3 rounded-lg border hover:bg-blue-100 transition-colors"
                    >
                      <RadioGroupItem value={index.toString()} id={`option-${index}`} />
                      <Label htmlFor={`option-${index}`} className="flex-1 cursor-pointer font-medium">
                        {option}
                      </Label>
                    </div>
                  ))}
                </RadioGroup>
              </div>

              <Button
                onClick={handleAnswer}
                disabled={!selectedAnswer}
                className="w-full bg-blue-600 hover:bg-blue-700 text-white"
                size="lg"
              >
                Confirm Answer
              </Button>
            </>
          ) : (
            <div className="space-y-4">
              <div
                className={`p-6 rounded-lg ${
                  Number.parseInt(selectedAnswer) === questions[currentQuestion].correct
                    ? "bg-green-50 border-2 border-green-200"
                    : "bg-red-50 border-2 border-red-200"
                }`}
              >
                <div className="flex items-center mb-3">
                  {Number.parseInt(selectedAnswer) === questions[currentQuestion].correct ? (
                    <>
                      <div className="w-8 h-8 bg-green-500 rounded-full flex items-center justify-center mr-3">
                        <span className="text-white font-bold">✓</span>
                      </div>
                      <span className="text-green-800 font-semibold text-lg">Correct! +$25 discount</span>
                    </>
                  ) : (
                    <>
                      <div className="w-8 h-8 bg-red-500 rounded-full flex items-center justify-center mr-3">
                        <span className="text-white font-bold">✗</span>
                      </div>
                      <span className="text-red-800 font-semibold text-lg">Incorrect</span>
                    </>
                  )}
                </div>

                <p className="text-gray-700 mb-3">
                  <strong>Correct answer:</strong>{" "}
                  {questions[currentQuestion].options[questions[currentQuestion].correct]}
                </p>

                <p className="text-gray-600 text-sm">{questions[currentQuestion].explanation}</p>
              </div>

              <Button onClick={nextQuestion} className="w-full bg-blue-600 hover:bg-blue-700 text-white" size="lg">
                {currentQuestion < questions.length - 1 ? "Next Question" : "See Final Result"}
              </Button>
            </div>
          )}

          <div className="bg-gray-50 p-4 rounded-lg">
            <div className="flex justify-between items-center">
              <span className="text-sm text-gray-600">Discount progress:</span>
              <span className="font-semibold">${correctAnswers * 25} / $100</span>
            </div>
            <Progress value={(correctAnswers / 4) * 100} className="mt-2" />
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
