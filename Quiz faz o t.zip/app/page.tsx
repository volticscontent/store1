"use client"

import PSGQuiz from "../psg-quiz"

export default function Page() {
  return <PSGQuiz />
}
